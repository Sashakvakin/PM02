﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Математическое_моделирование
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void SolveTheEquation_Click(object sender, RoutedEventArgs e)
        {
            // Получаем данные из TextBox
            double zF_number_x1 = Convert.ToDouble(F_number_x1.Text);
            double zF_number_x2 = Convert.ToDouble(F_number_x2.Text);
            double zFirstRow_number_x1 = Convert.ToDouble(FirstRow_number_x1.Text);
            double zFirstRow_number_x2 = Convert.ToDouble(FirstRow_number_x2.Text);
            double zFirstRow_number_lessORrequally = Convert.ToDouble(FirstRow_number_lessORrequally.Text);
            double zSecondRow_number_x1 = Convert.ToDouble(SecondRow_number_x1.Text);
            double zSecondRow_number_x2 = Convert.ToDouble(SecondRow_number_x2.Text);
            double zSecondRow_number_lessORrequally = Convert.ToDouble(SecondRow_number_lessORrequally.Text);
            double zThirdRow_number_x1 = Convert.ToDouble(ThirdRow_number_x1.Text);
            double zThirdRow_number_x2 = Convert.ToDouble(ThirdRow_number_x2.Text);
            double zThirdRow_number_lessORrequally = Convert.ToDouble(ThirdRow_number_lessORrequally.Text);

            // Создаем ограничения
            List<Line> ограничения = new List<Line>();
            ограничения.Add(CreateLine(zFirstRow_number_x1, zFirstRow_number_x2, zFirstRow_number_lessORrequally, FirstRow_Znak.Content.ToString()));
            ограничения.Add(CreateLine(zSecondRow_number_x1, zSecondRow_number_x2, zSecondRow_number_lessORrequally, SecondRow_Znak.Content.ToString()));
            ограничения.Add(CreateLine(zThirdRow_number_x1, zThirdRow_number_x2, zThirdRow_number_lessORrequally, ThirdRow_Znak.Content.ToString()));

            // Определяем область допустимых решений
            Point[] вершины = FindVertices(ограничения);

            // Находим точку с максимальным значением F(x)
            double maxF = double.MinValue;
            Point оптимальнаяТочка = new Point();
            foreach (Point вершина in вершины)
            {
                double F = zF_number_x1 * вершина.X + zF_number_x2 * вершина.Y;
                if (F > maxF)
                {
                    maxF = F;
                    оптимальнаяТочка = вершина;
                }
            }
            Opt.Text = $"({оптимальнаяТочка.X}, {оптимальнаяТочка.Y})";
            Max.Text = $"{maxF}";
        }

        // Создает линию, заданную уравнением ax + by = c
        private Line CreateLine(double a, double b, double c, string знак)
        {
            Line линия = new Line();
            // Определяем точки на линии
            Point точка1 = new Point(0, c / b);
            Point точка2 = new Point(c / a, 0);
            // Задаем свойства линии
            линия.X1 = точка1.X;
            линия.Y1 = точка1.Y;
            линия.X2 = точка2.X;
            линия.Y2 = точка2.Y;
            линия.Stroke = Brushes.Blue;
            if (знак == "⩾")
            {
                // Переворачиваем точки, если знак больше или равно
                double tempX = линия.X1;
                линия.X1 = линия.X2;
                линия.X2 = tempX;
                double tempY = линия.Y1;
                линия.Y1 = линия.Y2;
                линия.Y2 = tempY;
            }
            return линия;
        }

        // Находит вершины области допустимых решений
        private Point[] FindVertices(List<Line> ограничения)
        {
            // Находим пересечения линий
            List<Point> точкиПересечения = new List<Point>();
            for (int i = 0; i < ограничения.Count; i++)
            {
                for (int j = i + 1; j < ограничения.Count; j++)
                {
                    Point точка = FindIntersection(ограничения[i], ограничения[j]);
                    if (точка.X != 0 || точка.Y != 0)
                    {
                        точкиПересечения.Add(точка);
                    }
                }
            }

            // Фильтруем точки, лежащие в области допустимых решений
            List<Point> вершины = new List<Point>();
            foreach (Point точка in точкиПересечения)
            {
                if (IsPointInRegion(точка, ограничения))
                {
                    вершины.Add(точка);
                }
            }

            return вершины.ToArray();
        }

        // Находит точку пересечения двух линий
        private Point FindIntersection(Line линия1, Line линия2)
        {
            // Вычисляем уравнения линий
            double a1 = (линия1.Y2 - линия1.Y1) / (линия1.X2 - линия1.X1);
            double b1 = линия1.Y1 - a1 * линия1.X1;
            double a2 = (линия2.Y2 - линия2.Y1) / (линия2.X2 - линия2.X1);
            double b2 = линия2.Y1 - a2 * линия2.X1;

            // Проверяем, пересекаются ли линии
            if (a1 == a2)
            {
                return new Point(); // Линии параллельны
            }

            // Вычисляем координаты точки пересечения
            double x = (b2 - b1) / (a1 - a2);
            double y = a1 * x + b1;
            return new Point(x, y);
        }

        // Проверяет, лежит ли точка в области, ограниченной линиями
        private bool IsPointInRegion(Point точка, List<Line> ограничения)
        {
            foreach (Line линия in ограничения)
            {
                // Вычисляем уравнение линии
                double a = (линия.Y2 - линия.Y1) / (линия.X2 - линия.X1);
                double b = линия.Y1 - a * линия.X1;

                // Проверяем, находится ли точка выше или ниже линии
                double y = a * точка.X + b;
                if (точка.Y > y)
                {
                    return false;
                }
            }
            return true;
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            F_number_x1.Text = "2";
            F_number_x2.Text = "3";
            FirstRow_number_x1.Text = "2";
            FirstRow_number_x2.Text = "1";
            FirstRow_number_lessORrequally.Text = "10";
            SecondRow_number_x1.Text = "-2";
            SecondRow_number_x2.Text = "3";
            SecondRow_number_lessORrequally.Text = "6";
            ThirdRow_number_x1.Text = "2";
            ThirdRow_number_x2.Text = "4";
            ThirdRow_number_lessORrequally.Text = "8";
            FirstRow_Znak.Content = "⩽";
            SecondRow_Znak.Content = "⩽";
            ThirdRow_Znak.Content = "⩽";
        }

        private void RadioButton_Checked_1(object sender, RoutedEventArgs e)
        {
            F_number_x1.Text = "3";
            F_number_x2.Text = "4";
            FirstRow_number_x1.Text = "1";
            FirstRow_number_x2.Text = "2";
            FirstRow_number_lessORrequally.Text = "4";
            SecondRow_number_x1.Text = "1";
            SecondRow_number_x2.Text = "3";
            SecondRow_number_lessORrequally.Text = "3";
            ThirdRow_number_x1.Text = "2";
            ThirdRow_number_x2.Text = "1";
            ThirdRow_number_lessORrequally.Text = "8";
            FirstRow_Znak.Content = "⩽";
            SecondRow_Znak.Content = "⩽";
            ThirdRow_Znak.Content = "⩾";
        }

        private void FirstRow_LessOrEqually_Click(object sender, RoutedEventArgs e)
        {
            FirstRow_Znak.Content = "⩽";
        }

        private void SecondRow_LessOrEqually_Click(object sender, RoutedEventArgs e)
        {
            SecondRow_Znak.Content = "⩽";
        }

        private void ThirdRow_LessOrEqually_Click(object sender, RoutedEventArgs e)
        {
            ThirdRow_Znak.Content = "⩾";
        }

        private void FirstRow_MoreOrEqually_Click(object sender, RoutedEventArgs e)
        {
            FirstRow_Znak.Content = "⩽";
        }

        private void SecondRow_MoreOrEqually_Click(object sender, RoutedEventArgs e)
        {
            SecondRow_Znak.Content = "⩽";
        }

        private void ThirdRow_MoreOrEqually_Click(object sender, RoutedEventArgs e)
        {
            ThirdRow_Znak.Content = "⩽";
        }
    }
}