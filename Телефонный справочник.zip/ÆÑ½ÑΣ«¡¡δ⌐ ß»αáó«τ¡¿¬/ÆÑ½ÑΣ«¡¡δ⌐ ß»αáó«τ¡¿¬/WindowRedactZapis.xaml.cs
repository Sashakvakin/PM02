﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Телефонный_справочник
{
    /// <summary>
      /// Логика взаимодействия для WindowRedactZapis.xaml
      /// </summary>
    public partial class WindowRedactZapis : Window
    {
        public WindowRedactZapis()
        {
            InitializeComponent();
            LoadContactIDs();
        }

        private void LoadContactIDs()
        {
            using (var db = new user05Entities2())
            {
                cbID.ItemsSource = db.Контакт.Select(c => c.id_контакта).ToList();
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new user05Entities2())
            {
                int selectedId = (int)cbID.SelectedValue;
                var contact = db.Контакт.SingleOrDefault(c => c.id_контакта == selectedId);

                if (contact != null)
                {
                    contact.id_группы_контактов = int.Parse(tbIDGroupKont.Text);
                    contact.Фамилия = tbFimale.Text;
                    contact.Имя = tbName.Text;
                    contact.Отчество = tbOtchestvo.Text;
                    contact.Номер_телефона = tbPhone.Text;
                    contact.E_mail = tbMail.Text;
                    contact.Компания = tbCompany.Text;
                    contact.Должность = tbDolznost.Text;
                    contact.Дата_рождения = dpDateBirthdate.SelectedDate;

                    db.SaveChanges();
                    MessageBox.Show("Данные сохранены.");
                }
                else
                {
                    MessageBox.Show("Заполните все данные корректно");
                }
            }
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cbID.SelectedItem != null)
            {
                using (var db = new user05Entities2())
                {
                    int selectedId = (int)cbID.SelectedValue;

                    var contact = db.Контакт.SingleOrDefault(c => c.id_контакта == selectedId);

                    if (contact != null)
                    {
                        tbIDGroupKont.Text = contact.id_группы_контактов.ToString();
                        tbFimale.Text = contact.Фамилия;
                        tbName.Text = contact.Имя;
                        tbOtchestvo.Text = contact.Отчество;
                        tbPhone.Text = contact.Номер_телефона;
                        tbMail.Text = contact.E_mail;
                        tbCompany.Text = contact.Компания;
                        tbDolznost.Text = contact.Должность;
                        dpDateBirthdate.SelectedDate = contact.Дата_рождения;
                    }
                }
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainwindowww = new MainWindow();
            mainwindowww.Show();
            this.Close();
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (cbID.SelectedItem != null)
            {
                var messageBoxResult = MessageBox.Show("Вы уверены, что хотите удалить запись?", "Удаление записи", MessageBoxButton.YesNo);
                if (messageBoxResult == MessageBoxResult.Yes)
                {
                    using (var db = new user05Entities2())
                    {
                        int selectedId = (int)cbID.SelectedValue;
                        var contact = db.Контакт.SingleOrDefault(c => c.id_контакта == selectedId);

                        if (contact != null)
                        {
                            db.Контакт.Remove(contact);
                            db.SaveChanges();

                            LoadContactIDs();  // Reload contact IDs after deletion

                            MessageBox.Show("Запись удалена.");
                        }
                        else
                        {
                            MessageBox.Show("Ошибка удаления записи.");
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите id контакта.");
            }
        }
    }
}
