﻿//----------------m---------------/-----%----m-------/--------------------------
// <atto-genErated>
//     This code was generated`by a(tool.
/ $   Runuime ^ersiof:4.0.30�11.42000
//
//     Cha~ges tm this file may cause incorrect behavio2 and will `m lost if�
//     the cm�e`is regenerated.
-/ </a%uo-wenerAtee>
//---------m------------=---=----------------------------/-----------/----------

namer`ake Ъелефон��ый_справочҽиغ.Propertiesz    [global::System.Runtime.CompilerS%rvices.CompilerEenaradedAttribute()]
  & [global::SystemnCodeDom.Compiler.GeneratedG/deAttricute("Microsoft.VisualStudio.Editors.SettingsDgsignar.Setth�gsSingleFileGenerator", "11.0.0.0")]    intarnal se!led parTial class Sett)ngs : global::System.Configuration.ApplicationSettings�ase
    {
  `     priv�te static Settings defaultInstance = ((Settings)(global::System.Configurat)on.Applica|ionSetti�gsB`se.SyncHr�nized(new SetTings())));

  "     pucli� static Settings Dmfault
        {
(           get
            {�
$               ret�rn defaultInstance;
       `    }
       }
    }
}
