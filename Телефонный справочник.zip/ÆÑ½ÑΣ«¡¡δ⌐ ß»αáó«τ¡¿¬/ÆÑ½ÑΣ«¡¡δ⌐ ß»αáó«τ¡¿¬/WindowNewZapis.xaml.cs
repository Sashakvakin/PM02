﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Телефонный_справочник;
using System.Text.RegularExpressions;

namespace Телефонный_справочник
{
    public partial class WindowNewZapis : Window
    {
        public WindowNewZapis()
        {
            InitializeComponent();
        }

        private void CreateNewKontakt_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Проверка номера телефона по маске
                if (!IsValidPhoneNumber(tbPhone.Text))
                {
                    MessageBox.Show("Неверный формат номера телефона. Пример: +7(922)654-66-99.");
                    return;
                }

                // Проверка e-mail по заданным правилам
                if (!IsValidEmail(tbMail.Text))
                {
                    MessageBox.Show("Неверный формат e-mail. Проверьте правильность ввода.");
                    return;
                }

                using (var db = new user05Entities2())
                {
                    var newContact = new Контакт();
                    newContact.id_контакта = Convert.ToInt32(tbID.Text); ;
                    newContact.id_группы_контактов = Convert.ToInt32(tbIDGroupKont.Text);
                    newContact.Фамилия = tbFimale.Text;
                    newContact.Имя = tbName.Text;
                    newContact.Отчество = tbOtchestvo.Text;
                    newContact.Номер_телефона = tbPhone.Text;
                    newContact.E_mail = tbMail.Text;
                    newContact.Компания = tbCompany.Text;
                    newContact.Должность = tbDolznost.Text;
                    newContact.Дата_рождения = Convert.ToDateTime(dpDateBirthdate.Text);


                    db.Контакт.Add(newContact);
                    db.SaveChanges();
                }

                MessageBox.Show("Новый контакт добавлен.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка добавления записи" + ex.Message);
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        // Метод проверки номера телефона по маске
        private bool IsValidPhoneNumber(string phoneNumber)
        {
            string pattern = @"^\+7\(\d{3}\)\d{3}-\d{2}-\d{2}$";
            return Regex.IsMatch(phoneNumber, pattern);
        }

        // Метод проверки e-mail по заданным правилам
        private bool IsValidEmail(string email)
        {
            string pattern = @"^[a-zA-Z0-9]+@[a-zA-Z0-9]+\.[a-zA-Z]{2,5}$";
            return Regex.IsMatch(email, pattern);
        }
    }
}