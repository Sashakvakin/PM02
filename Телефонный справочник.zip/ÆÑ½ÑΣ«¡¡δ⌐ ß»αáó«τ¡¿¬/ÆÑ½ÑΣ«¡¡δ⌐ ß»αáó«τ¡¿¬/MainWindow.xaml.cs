﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;
using System.Data;

namespace Телефонный_справочник
{

    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LoadContacts();
        }

        private void LoadContacts()
        {
            try
            {
                using (var db = new user05Entities2())
                {
                    var contacts = (from c in db.Контакт
                                    join g in db.ГруппаКонтактов on c.id_группы_контактов equals g.id_группы_контактов
                                    select new
                                    {
                                        c.id_контакта,
                                        ГруппаКонтактов = g.Наименование,
                                        c.Фамилия,
                                        c.Имя,
                                        c.Отчество,
                                        НомерТелефона = c.Номер_телефона,
                                        c.E_mail,
                                        c.Компания,
                                        c.Должность,
                                        ДатаРождения = c.Дата_рождения,
                                        c.Фотография
                                        
                                    }).ToList();

                    DataGridKontakt.ItemsSource = contacts;
                }
            }
            catch
            {
                MessageBox.Show("Ошибка импорта данных");
            }
        }

        private void ButtonNewKontakt_Click(object sender, RoutedEventArgs e)
        {
            WindowNewZapis windowNewZapis = new WindowNewZapis();
            windowNewZapis.Show();
            this.Close();
        }

        private void ButtonRedactKontakt_Click(object sender, RoutedEventArgs e)
        {
            WindowRedactZapis windowRedactZapis = new WindowRedactZapis();
            windowRedactZapis.Show();
            this.Close();
        }
    }
}